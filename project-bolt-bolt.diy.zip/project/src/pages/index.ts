export { default as BrandingPage } from './BrandingPage';
export { default as CapsulePage } from './CapsulePage';
export { default as WellDyingPage } from './WellDyingPage';
export { default as EducationPage } from './EducationPage';
export { default as ExpertsPage } from './ExpertsPage';