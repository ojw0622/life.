import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Palette, Sparkles, Download, Share2, Eye, Edit3 } from 'lucide-react';

export default function BrandingPage() {
  const [selectedTemplate, setSelectedTemplate] = useState(0);
  const [brandData, setBrandData] = useState({
    name: '',
    tagline: '',
    story: '',
    values: '',
    color: '#3B82F6'
  });

  const templates = [
    {
      id: 0,
      name: '클래식 엘레간트',
      preview: 'bg-gradient-to-br from-gray-800 to-gray-900',
      description: '세련되고 전문적인 느낌의 클래식한 디자인'
    },
    {
      id: 1,
      name: '모던 미니멀',
      preview: 'bg-gradient-to-br from-blue-500 to-purple-600',
      description: '깔끔하고 현대적인 미니멀 디자인'
    },
    {
      id: 2,
      name: '크리에이티브',
      preview: 'bg-gradient-to-br from-pink-500 to-orange-500',
      description: '창의적이고 역동적인 컬러풀한 디자인'
    },
    {
      id: 3,
      name: '내추럴',
      preview: 'bg-gradient-to-br from-green-500 to-teal-600',
      description: '자연스럽고 따뜻한 느낌의 친근한 디자인'
    }
  ];

  const handleInputChange = (field: string, value: string) => {
    setBrandData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 rounded-full px-6 py-2 mb-6">
            <Palette className="w-5 h-5" />
            <span className="font-medium">개인 브랜딩</span>
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            📘 나만의 <span className="gradient-text">브랜드</span>를 만들어보세요
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            당신의 독특한 이야기와 가치를 담은 개인 브랜드를 제작하고, 
            세상에 당신만의 색깔을 보여주세요.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Panel - Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            {/* Basic Information */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Edit3 className="w-6 h-6 text-purple-600" />
                기본 정보
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    브랜드 이름
                  </label>
                  <input
                    type="text"
                    value={brandData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="예: 김철수의 라이프스토리"
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    태그라인
                  </label>
                  <input
                    type="text"
                    value={brandData.tagline}
                    onChange={(e) => handleInputChange('tagline', e.target.value)}
                    placeholder="예: 평범한 일상 속 특별한 순간들"
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    브랜드 컬러
                  </label>
                  <div className="flex items-center gap-4">
                    <input
                      type="color"
                      value={brandData.color}
                      onChange={(e) => handleInputChange('color', e.target.value)}
                      className="w-16 h-12 border-2 border-gray-200 rounded-xl cursor-pointer"
                    />
                    <span className="text-gray-600 font-mono">{brandData.color}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Story & Values */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-purple-600" />
                스토리 & 가치관
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    나의 이야기
                  </label>
                  <textarea
                    rows={4}
                    value={brandData.story}
                    onChange={(e) => handleInputChange('story', e.target.value)}
                    placeholder="당신만의 특별한 이야기를 들려주세요..."
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all resize-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    핵심 가치관
                  </label>
                  <textarea
                    rows={3}
                    value={brandData.values}
                    onChange={(e) => handleInputChange('values', e.target.value)}
                    placeholder="당신이 중요하게 생각하는 가치들을 적어주세요..."
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Template Selection */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                템플릿 선택
              </h2>
              
              <div className="grid grid-cols-2 gap-4">
                {templates.map((template) => (
                  <motion.div
                    key={template.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedTemplate(template.id)}
                    className={`cursor-pointer rounded-xl p-4 border-2 transition-all ${
                      selectedTemplate === template.id
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <div className={`w-full h-20 rounded-lg mb-3 ${template.preview}`}></div>
                    <h3 className="font-semibold text-gray-900 mb-1">{template.name}</h3>
                    <p className="text-xs text-gray-600">{template.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Right Panel - Preview */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-8"
          >
            {/* Preview Card */}
            <div className="bg-white rounded-2xl p-8 shadow-lg sticky top-32">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Eye className="w-6 h-6 text-purple-600" />
                  미리보기
                </h2>
                <div className="flex gap-2">
                  <button className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                    <Share2 className="w-5 h-5 text-gray-600" />
                  </button>
                  <button className="p-2 bg-purple-100 rounded-lg hover:bg-purple-200 transition-colors">
                    <Download className="w-5 h-5 text-purple-600" />
                  </button>
                </div>
              </div>
              
              {/* Brand Card Preview */}
              <div className={`rounded-2xl p-8 text-white ${templates[selectedTemplate].preview} relative overflow-hidden`}>
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute top-4 right-4 w-32 h-32 bg-white rounded-full blur-2xl"></div>
                  <div className="absolute bottom-4 left-4 w-24 h-24 bg-white rounded-full blur-xl"></div>
                </div>
                
                <div className="relative z-10">
                  <h1 className="text-3xl font-bold mb-2">
                    {brandData.name || '브랜드 이름'}
                  </h1>
                  <p className="text-lg opacity-90 mb-6">
                    {brandData.tagline || '태그라인을 입력해주세요'}
                  </p>
                  
                  {brandData.story && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-2">나의 이야기</h3>
                      <p className="text-sm opacity-80 leading-relaxed">
                        {brandData.story}
                      </p>
                    </div>
                  )}
                  
                  {brandData.values && (
                    <div>
                      <h3 className="text-lg font-semibold mb-2">핵심 가치관</h3>
                      <p className="text-sm opacity-80 leading-relaxed">
                        {brandData.values}
                      </p>
                    </div>
                  )}
                  
                  <div 
                    className="absolute bottom-4 right-4 w-4 h-4 rounded-full"
                    style={{ backgroundColor: brandData.color }}
                  ></div>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="mt-6 flex gap-3">
                <button className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold py-3 rounded-xl hover:shadow-lg transition-all">
                  브랜드 생성하기
                </button>
                <button className="px-6 bg-gray-100 text-gray-700 font-semibold py-3 rounded-xl hover:bg-gray-200 transition-colors">
                  저장
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}