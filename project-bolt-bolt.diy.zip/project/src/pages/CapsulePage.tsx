import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Package, Calendar, Lock, Send, Clock, Heart, Star, Gift } from 'lucide-react';

export default function CapsulePage() {
  const [capsuleData, setCapsuleData] = useState({
    title: '',
    message: '',
    recipient: '',
    openDate: '',
    isPrivate: true
  });

  const [capsules, setCapsules] = useState([
    {
      id: 1,
      title: '30살의 나에게',
      openDate: '2026-12-31',
      status: 'sealed',
      daysLeft: 365
    },
    {
      id: 2,
      title: '결혼 10주년 기념',
      openDate: '2027-06-15',
      status: 'sealed',
      daysLeft: 580
    },
    {
      id: 3,
      title: '첫 직장 입사 기념',
      openDate: '2025-03-01',
      status: 'opened',
      daysLeft: 0
    }
  ]);

  const handleInputChange = (field: string, value: string | boolean) => {
    setCapsuleData(prev => ({ ...prev, [field]: value }));
  };

  const handleCreateCapsule = () => {
    if (capsuleData.title && capsuleData.message && capsuleData.openDate) {
      const newCapsule = {
        id: capsules.length + 1,
        title: capsuleData.title,
        openDate: capsuleData.openDate,
        status: 'sealed' as const,
        daysLeft: Math.ceil((new Date(capsuleData.openDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
      };
      setCapsules(prev => [newCapsule, ...prev]);
      setCapsuleData({
        title: '',
        message: '',
        recipient: '',
        openDate: '',
        isPrivate: true
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 rounded-full px-6 py-2 mb-6">
            <Package className="w-5 h-5" />
            <span className="font-medium">디지털 타임캡슐</span>
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            📦 미래의 나에게 보내는 <span className="gradient-text">선물</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            현재의 생각과 감정을 담아 미래의 특별한 순간에 열어볼 수 있는 
            디지털 타임캡슐을 만들어보세요.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Panel - Create Capsule */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Gift className="w-6 h-6 text-emerald-600" />
                새 타임캡슐 만들기
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    캡슐 제목
                  </label>
                  <input
                    type="text"
                    value={capsuleData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    placeholder="예: 25살의 나에게"
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-emerald-400 focus:ring-4 focus:ring-emerald-100 transition-all"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    메시지
                  </label>
                  <textarea
                    rows={6}
                    value={capsuleData.message}
                    onChange={(e) => handleInputChange('message', e.target.value)}
                    placeholder="미래의 나에게 전하고 싶은 메시지를 작성해주세요..."
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-emerald-400 focus:ring-4 focus:ring-emerald-100 transition-all resize-none"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    받는 사람 (선택사항)
                  </label>
                  <input
                    type="text"
                    value={capsuleData.recipient}
                    onChange={(e) => handleInputChange('recipient', e.target.value)}
                    placeholder="예: 미래의 나, 자녀, 배우자 등"
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-emerald-400 focus:ring-4 focus:ring-emerald-100 transition-all"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    개봉 날짜
                  </label>
                  <input
                    type="date"
                    value={capsuleData.openDate}
                    onChange={(e) => handleInputChange('openDate', e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full border-2 border-gray-200 rounded-xl p-4 focus:outline-none focus:border-emerald-400 focus:ring-4 focus:ring-emerald-100 transition-all"
                  />
                </div>
                
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="private"
                    checked={capsuleData.isPrivate}
                    onChange={(e) => handleInputChange('isPrivate', e.target.checked)}
                    className="w-5 h-5 text-emerald-600 rounded focus:ring-emerald-500"
                  />
                  <label htmlFor="private" className="text-sm text-gray-700 flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    비공개 캡슐 (나만 볼 수 있음)
                  </label>
                </div>
              </div>
              
              <button
                onClick={handleCreateCapsule}
                disabled={!capsuleData.title || !capsuleData.message || !capsuleData.openDate}
                className="w-full mt-8 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold py-4 rounded-xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                타임캡슐 봉인하기
              </button>
            </div>
          </motion.div>

          {/* Right Panel - My Capsules */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-8"
          >
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Clock className="w-6 h-6 text-emerald-600" />
                나의 타임캡슐
              </h2>
              
              <div className="space-y-4">
                {capsules.map((capsule, index) => (
                  <motion.div
                    key={capsule.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className={`p-6 rounded-xl border-2 transition-all ${
                      capsule.status === 'sealed'
                        ? 'border-emerald-200 bg-emerald-50'
                        : 'border-gray-200 bg-gray-50'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-1">
                          {capsule.title}
                        </h3>
                        <p className="text-sm text-gray-600 flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(capsule.openDate).toLocaleDateString('ko-KR')} 개봉
                        </p>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                        capsule.status === 'sealed'
                          ? 'bg-emerald-100 text-emerald-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {capsule.status === 'sealed' ? '봉인됨' : '개봉됨'}
                      </div>
                    </div>
                    
                    {capsule.status === 'sealed' && (
                      <div className="flex items-center gap-2 text-emerald-600">
                        <Heart className="w-4 h-4" />
                        <span className="text-sm font-medium">
                          {capsule.daysLeft}일 후 개봉 가능
                        </span>
                      </div>
                    )}
                    
                    {capsule.status === 'opened' && (
                      <button className="text-sm text-gray-600 hover:text-gray-800 transition-colors">
                        메시지 다시 보기 →
                      </button>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
            
            {/* Statistics */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6">통계</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Package className="w-8 h-8 text-emerald-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{capsules.filter(c => c.status === 'sealed').length}</div>
                  <div className="text-sm text-gray-600">봉인된 캡슐</div>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Star className="w-8 h-8 text-gray-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{capsules.filter(c => c.status === 'opened').length}</div>
                  <div className="text-sm text-gray-600">개봉한 캡슐</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}