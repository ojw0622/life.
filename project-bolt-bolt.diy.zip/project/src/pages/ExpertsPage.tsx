import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Star, MessageCircle, Calendar, Award, MapPin, Clock, Filter, Search, Video, Phone } from 'lucide-react';

export default function ExpertsPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [bookedExperts, setBookedExperts] = useState<number[]>([]);

  const categories = [
    { id: 'all', label: '전체 전문가' },
    { id: 'life-coach', label: '라이프 코치' },
    { id: 'storytelling', label: '스토리텔링' },
    { id: 'branding', label: '브랜딩' },
    { id: 'well-dying', label: '웰다잉' },
    { id: 'psychology', label: '심리상담' }
  ];

  const experts = [
    {
      id: 1,
      name: '김라이프',
      title: '라이프 코치',
      category: 'life-coach',
      specialties: ['인생 설계', '목표 달성', '자기계발'],
      rating: 4.9,
      reviews: 127,
      experience: '15년',
      location: '서울',
      price: '80,000원/시간',
      avatar: 'bg-gradient-to-br from-blue-500 to-purple-600',
      description: '개인의 잠재력을 최대한 발휘할 수 있도록 도와주는 전문 라이프 코치입니다.',
      consultationTypes: ['화상 상담', '대면 상담'],
      languages: ['한국어', '영어'],
      availability: '평일 오후, 주말'
    },
    {
      id: 2,
      name: '박스토리',
      title: '스토리텔링 전문가',
      category: 'storytelling',
      specialties: ['개인사 정리', '인터뷰 기법', '글쓰기'],
      rating: 4.8,
      reviews: 89,
      experience: '12년',
      location: '부산',
      price: '60,000원/시간',
      avatar: 'bg-gradient-to-br from-pink-500 to-orange-500',
      description: '당신만의 특별한 이야기를 발견하고 의미있게 정리하는 전문가입니다.',
      consultationTypes: ['화상 상담', '전화 상담'],
      languages: ['한국어'],
      availability: '평일 저녁, 주말'
    },
    {
      id: 3,
      name: '이브랜딩',
      title: '개인 브랜딩 컨설턴트',
      category: 'branding',
      specialties: ['개인 브랜딩', 'SNS 마케팅', '이미지 메이킹'],
      rating: 4.9,
      reviews: 156,
      experience: '10년',
      location: '서울',
      price: '100,000원/시간',
      avatar: 'bg-gradient-to-br from-purple-500 to-pink-500',
      description: '디지털 시대에 맞는 개인 브랜드 구축과 관리를 전문으로 합니다.',
      consultationTypes: ['화상 상담', '대면 상담'],
      languages: ['한국어', '영어', '중국어'],
      availability: '평일 오전, 오후'
    },
    {
      id: 4,
      name: '정웰다잉',
      title: '웰다잉 상담사',
      category: 'well-dying',
      specialties: ['생애 마무리', '유언 작성', '가족 상담'],
      rating: 4.7,
      reviews: 73,
      experience: '8년',
      location: '대구',
      price: '70,000원/시간',
      avatar: 'bg-gradient-to-br from-rose-500 to-pink-500',
      description: '아름다운 마무리를 위한 준비와 가족 간의 소통을 도와드립니다.',
      consultationTypes: ['대면 상담', '화상 상담'],
      languages: ['한국어'],
      availability: '평일 전체, 토요일'
    },
    {
      id: 5,
      name: '최심리',
      title: '임상심리사',
      category: 'psychology',
      specialties: ['트라우마 치료', '우울증', '불안장애'],
      rating: 4.9,
      reviews: 203,
      experience: '18년',
      location: '서울',
      price: '90,000원/시간',
      avatar: 'bg-gradient-to-br from-green-500 to-teal-600',
      description: '마음의 상처를 치유하고 건강한 정신건강을 위해 함께합니다.',
      consultationTypes: ['대면 상담', '화상 상담'],
      languages: ['한국어', '영어'],
      availability: '평일 오후, 저녁'
    },
    {
      id: 6,
      name: '한인터뷰',
      title: '인터뷰 전문가',
      category: 'storytelling',
      specialties: ['인생 인터뷰', '구술사', '기록 보존'],
      rating: 4.6,
      reviews: 94,
      experience: '7년',
      location: '인천',
      price: '55,000원/시간',
      avatar: 'bg-gradient-to-br from-yellow-500 to-orange-500',
      description: '소중한 인생 이야기를 체계적으로 기록하고 보존하는 전문가입니다.',
      consultationTypes: ['대면 상담', '화상 상담', '전화 상담'],
      languages: ['한국어'],
      availability: '주말, 평일 저녁'
    }
  ];

  const filteredExperts = experts.filter(expert => {
    const matchesCategory = selectedCategory === 'all' || expert.category === selectedCategory;
    const matchesSearch = expert.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expert.specialties.some(specialty => 
                           specialty.toLowerCase().includes(searchTerm.toLowerCase())
                         );
    return matchesCategory && matchesSearch;
  });

  const handleBookConsultation = (expertId: number) => {
    if (!bookedExperts.includes(expertId)) {
      setBookedExperts(prev => [...prev, expertId]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-blue-50 to-indigo-50 pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-teal-100 text-teal-700 rounded-full px-6 py-3 mb-8">
            <Users className="w-5 h-5" />
            <span className="font-medium">전문가 매칭</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
            🤝 당신에게 맞는 <span className="bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">전문가</span>를 찾아보세요
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            각 분야의 검증된 전문가들과 1:1 상담을 통해 
            더 나은 삶을 설계하고 목표를 달성해보세요.
          </p>
        </motion.div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white rounded-3xl p-8 shadow-xl mb-12"
        >
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="전문가 이름, 분야, 전문 영역으로 검색..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-2xl focus:outline-none focus:border-teal-400 focus:ring-4 focus:ring-teal-100 transition-all"
              />
            </div>
            
            {/* Category Filter */}
            <div className="flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-6 py-3 rounded-2xl font-semibold transition-all duration-300 ${
                    selectedCategory === category.id
                      ? 'bg-gradient-to-r from-teal-500 to-blue-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-600 hover:bg-teal-50 hover:text-teal-600'
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Experts Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredExperts.map((expert, index) => (
            <motion.div
              key={expert.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300"
            >
              {/* Expert Header */}
              <div className="p-8 pb-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-20 h-20 ${expert.avatar} rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-lg`}>
                    {expert.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{expert.name}</h3>
                    <p className="text-teal-600 font-semibold">{expert.title}</p>
                  </div>
                </div>

                <p className="text-gray-600 mb-6 leading-relaxed">
                  {expert.description}
                </p>

                {/* Rating and Reviews */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-yellow-500 fill-current" />
                    <span className="font-bold text-gray-900">{expert.rating}</span>
                    <span className="text-gray-600">({expert.reviews})</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-600">
                    <Award className="w-4 h-4" />
                    {expert.experience} 경력
                  </div>
                </div>

                {/* Specialties */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-700 mb-3">전문 분야</h4>
                  <div className="flex flex-wrap gap-2">
                    {expert.specialties.map((specialty, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-teal-100 text-teal-700 rounded-full text-sm font-medium"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-3 mb-6 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    {expert.location}
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    {expert.availability}
                  </div>
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-4 h-4" />
                    {expert.consultationTypes.join(', ')}
                  </div>
                </div>

                {/* Price */}
                <div className="text-center mb-6">
                  <div className="text-2xl font-bold text-gray-900">{expert.price}</div>
                  <div className="text-sm text-gray-600">상담료</div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <button
                    onClick={() => handleBookConsultation(expert.id)}
                    disabled={bookedExperts.includes(expert.id)}
                    className={`w-full py-3 rounded-2xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
                      bookedExperts.includes(expert.id)
                        ? 'bg-green-100 text-green-700 cursor-default'
                        : 'bg-gradient-to-r from-teal-500 to-blue-500 text-white hover:shadow-lg hover:scale-105'
                    }`}
                  >
                    {bookedExperts.includes(expert.id) ? (
                      <>
                        <Calendar className="w-5 h-5" />
                        상담 예약됨
                      </>
                    ) : (
                      <>
                        <Calendar className="w-5 h-5" />
                        상담 예약하기
                      </>
                    )}
                  </button>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <button className="flex items-center justify-center gap-2 py-2 px-4 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors">
                      <Video className="w-4 h-4" />
                      화상
                    </button>
                    <button className="flex items-center justify-center gap-2 py-2 px-4 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors">
                      <Phone className="w-4 h-4" />
                      전화
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* No Results */}
        {filteredExperts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <div className="text-6xl mb-6">🔍</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">검색 결과가 없습니다</h3>
            <p className="text-gray-600 mb-8">다른 검색어나 카테고리를 시도해보세요.</p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
              className="bg-gradient-to-r from-teal-500 to-blue-500 text-white font-semibold px-8 py-3 rounded-2xl hover:shadow-lg transition-all"
            >
              전체 전문가 보기
            </button>
          </motion.div>
        )}

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <div className="bg-gradient-to-r from-teal-500 to-blue-600 rounded-3xl p-12 text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              전문가가 되고 싶으신가요?
            </h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              당신의 전문성을 많은 사람들과 공유하고 
              의미있는 변화를 만들어보세요.
            </p>
            <button className="bg-white text-teal-600 font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all hover:scale-105">
              전문가 등록하기
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}