import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Play, Clock, Users, Star, Award, ChevronRight, Calendar, Video, FileText } from 'lucide-react';

export default function EducationPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [enrolledCourses, setEnrolledCourses] = useState<number[]>([]);

  const categories = [
    { id: 'all', label: '전체', icon: BookOpen },
    { id: 'life-planning', label: '인생 설계', icon: Calendar },
    { id: 'storytelling', label: '스토리텔링', icon: FileText },
    { id: 'digital-legacy', label: '디지털 유산', icon: Video },
    { id: 'well-dying', label: '웰다잉', icon: Star }
  ];

  const courses = [
    {
      id: 1,
      title: '나만의 인생 스토리 만들기',
      description: '개인의 경험과 가치관을 바탕으로 의미있는 인생 이야기를 구성하는 방법을 배웁니다.',
      category: 'storytelling',
      duration: '4주',
      level: '초급',
      students: 1250,
      rating: 4.8,
      price: '무료',
      instructor: '김스토리 작가',
      thumbnail: 'bg-gradient-to-br from-blue-500 to-purple-600',
      lessons: 12,
      certificate: true
    },
    {
      id: 2,
      title: '디지털 시대의 개인 브랜딩',
      description: '온라인에서 자신만의 브랜드를 구축하고 관리하는 전략적 접근법을 학습합니다.',
      category: 'life-planning',
      duration: '6주',
      level: '중급',
      students: 890,
      rating: 4.9,
      price: '49,000원',
      instructor: '박브랜딩 전문가',
      thumbnail: 'bg-gradient-to-br from-pink-500 to-orange-500',
      lessons: 18,
      certificate: true
    },
    {
      id: 3,
      title: '웰다잉과 생애 마무리 준비',
      description: '아름다운 마무리를 위한 실질적인 준비 과정과 마음가짐을 다룹니다.',
      category: 'well-dying',
      duration: '3주',
      level: '초급',
      students: 567,
      rating: 4.7,
      price: '무료',
      instructor: '이웰다잉 상담사',
      thumbnail: 'bg-gradient-to-br from-rose-500 to-pink-500',
      lessons: 9,
      certificate: false
    },
    {
      id: 4,
      title: '디지털 유산 관리와 보존',
      description: '디지털 시대에 중요한 데이터와 추억을 안전하게 보존하고 전달하는 방법을 배웁니다.',
      category: 'digital-legacy',
      duration: '5주',
      level: '중급',
      students: 423,
      rating: 4.6,
      price: '39,000원',
      instructor: '최디지털 전문가',
      thumbnail: 'bg-gradient-to-br from-green-500 to-teal-600',
      lessons: 15,
      certificate: true
    },
    {
      id: 5,
      title: '인생 2막 설계하기',
      description: '새로운 시작을 위한 목표 설정과 실행 계획 수립 방법을 학습합니다.',
      category: 'life-planning',
      duration: '8주',
      level: '고급',
      students: 312,
      rating: 4.9,
      price: '79,000원',
      instructor: '정라이프 코치',
      thumbnail: 'bg-gradient-to-br from-indigo-500 to-purple-600',
      lessons: 24,
      certificate: true
    },
    {
      id: 6,
      title: '효과적인 인터뷰 기법',
      description: '자신과 타인의 이야기를 효과적으로 끌어내는 인터뷰 스킬을 익힙니다.',
      category: 'storytelling',
      duration: '4주',
      level: '초급',
      students: 678,
      rating: 4.5,
      price: '29,000원',
      instructor: '한인터뷰 전문가',
      thumbnail: 'bg-gradient-to-br from-yellow-500 to-orange-500',
      lessons: 12,
      certificate: false
    }
  ];

  const filteredCourses = selectedCategory === 'all' 
    ? courses 
    : courses.filter(course => course.category === selectedCategory);

  const handleEnroll = (courseId: number) => {
    if (!enrolledCourses.includes(courseId)) {
      setEnrolledCourses(prev => [...prev, courseId]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 rounded-full px-6 py-3 mb-8">
            <BookOpen className="w-5 h-5" />
            <span className="font-medium">라이프 교육</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
            🎓 인생을 더 풍요롭게 만드는 <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">교육</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            전문가들이 설계한 체계적인 교육 프로그램으로 
            더 의미있고 풍성한 인생을 만들어보세요.
          </p>
        </motion.div>

        {/* Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16"
        >
          <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
            <div className="text-3xl font-bold text-indigo-600 mb-2">50+</div>
            <div className="text-gray-600">강의 수</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">10K+</div>
            <div className="text-gray-600">수강생</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
            <div className="text-3xl font-bold text-pink-600 mb-2">4.8</div>
            <div className="text-gray-600">평균 평점</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">95%</div>
            <div className="text-gray-600">완주율</div>
          </div>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-3 px-6 py-3 rounded-2xl font-semibold transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-indigo-50 hover:text-indigo-600 shadow-md'
              }`}
            >
              <category.icon className="w-5 h-5" />
              {category.label}
            </button>
          ))}
        </motion.div>

        {/* Courses Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredCourses.map((course, index) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 group"
            >
              {/* Course Thumbnail */}
              <div className={`h-48 ${course.thumbnail} relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 backdrop-blur-sm text-gray-800 px-3 py-1 rounded-full text-sm font-semibold">
                    {course.level}
                  </span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="bg-white/90 backdrop-blur-sm text-gray-800 px-3 py-1 rounded-full text-sm font-semibold">
                    {course.price}
                  </span>
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Play className="w-8 h-8 text-white ml-1" />
                  </div>
                </div>
              </div>

              {/* Course Content */}
              <div className="p-8">
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm font-semibold text-gray-700">{course.rating}</span>
                  </div>
                  <span className="text-gray-400">•</span>
                  <div className="flex items-center gap-1 text-sm text-gray-600">
                    <Users className="w-4 h-4" />
                    {course.students.toLocaleString()}명
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                  {course.title}
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-3 leading-relaxed">
                  {course.description}
                </p>

                <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {course.duration}
                  </div>
                  <div className="flex items-center gap-1">
                    <Video className="w-4 h-4" />
                    {course.lessons}강
                  </div>
                  {course.certificate && (
                    <div className="flex items-center gap-1">
                      <Award className="w-4 h-4" />
                      수료증
                    </div>
                  )}
                </div>

                <div className="text-sm text-gray-600 mb-6">
                  강사: {course.instructor}
                </div>

                <button
                  onClick={() => handleEnroll(course.id)}
                  disabled={enrolledCourses.includes(course.id)}
                  className={`w-full py-3 rounded-2xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
                    enrolledCourses.includes(course.id)
                      ? 'bg-green-100 text-green-700 cursor-default'
                      : 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:shadow-lg hover:scale-105'
                  }`}
                >
                  {enrolledCourses.includes(course.id) ? (
                    <>
                      <Award className="w-5 h-5" />
                      수강 중
                    </>
                  ) : (
                    <>
                      수강 신청
                      <ChevronRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-3xl p-12 text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              더 많은 강의가 궁금하신가요?
            </h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              전문가들이 직접 설계한 맞춤형 교육 프로그램으로 
              당신의 인생을 한 단계 업그레이드해보세요.
            </p>
            <button className="bg-white text-indigo-600 font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all hover:scale-105">
              전체 강의 둘러보기
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}