import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, FileText, Users, Calendar, Lock, Send, Star, Flower, BookOpen, MessageCircle } from 'lucide-react';

export default function WellDyingPage() {
  const [activeTab, setActiveTab] = useState('messages');
  const [messageData, setMessageData] = useState({
    recipient: '',
    title: '',
    content: '',
    deliveryDate: '',
    isPrivate: true
  });

  const [savedMessages, setSavedMessages] = useState([
    {
      id: 1,
      recipient: '사랑하는 딸에게',
      title: '엄마의 마지막 편지',
      status: 'draft',
      createdAt: '2025-01-15'
    },
    {
      id: 2,
      recipient: '평생의 친구에게',
      title: '우리의 우정에 대한 감사',
      status: 'scheduled',
      createdAt: '2025-01-10'
    }
  ]);

  const handleInputChange = (field: string, value: string | boolean) => {
    setMessageData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveMessage = () => {
    if (messageData.recipient && messageData.title && messageData.content) {
      const newMessage = {
        id: savedMessages.length + 1,
        recipient: messageData.recipient,
        title: messageData.title,
        status: 'draft' as const,
        createdAt: new Date().toISOString().split('T')[0]
      };
      setSavedMessages(prev => [newMessage, ...prev]);
      setMessageData({
        recipient: '',
        title: '',
        content: '',
        deliveryDate: '',
        isPrivate: true
      });
    }
  };

  const tabs = [
    { id: 'messages', label: '마지막 메시지', icon: MessageCircle },
    { id: 'memories', label: '추억 정리', icon: Heart },
    { id: 'documents', label: '중요 문서', icon: FileText },
    { id: 'guidance', label: '가이드', icon: BookOpen }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-rose-100 text-rose-700 rounded-full px-6 py-3 mb-8">
            <Flower className="w-5 h-5" />
            <span className="font-medium">웰다잉 콘텐츠</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
            🌸 아름다운 <span className="bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">마무리</span>를 위한 준비
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            소중한 사람들에게 남길 메시지와 추억을 정리하고, 
            인생의 마지막 순간까지 의미있게 보낼 수 있도록 도와드립니다.
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-3 px-6 py-3 rounded-2xl font-semibold transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-rose-50 hover:text-rose-600 shadow-md'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'messages' && (
            <motion.div
              key="messages"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12"
            >
              {/* Create Message */}
              <div className="bg-white rounded-3xl p-10 shadow-xl border border-gray-100">
                <h2 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-3">
                  <MessageCircle className="w-8 h-8 text-rose-600" />
                  마지막 메시지 작성
                </h2>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      받는 사람
                    </label>
                    <input
                      type="text"
                      value={messageData.recipient}
                      onChange={(e) => handleInputChange('recipient', e.target.value)}
                      placeholder="예: 사랑하는 가족에게"
                      className="w-full border-2 border-gray-200 rounded-2xl p-4 focus:outline-none focus:border-rose-400 focus:ring-4 focus:ring-rose-100 transition-all"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      제목
                    </label>
                    <input
                      type="text"
                      value={messageData.title}
                      onChange={(e) => handleInputChange('title', e.target.value)}
                      placeholder="메시지 제목을 입력하세요"
                      className="w-full border-2 border-gray-200 rounded-2xl p-4 focus:outline-none focus:border-rose-400 focus:ring-4 focus:ring-rose-100 transition-all"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      메시지 내용
                    </label>
                    <textarea
                      rows={8}
                      value={messageData.content}
                      onChange={(e) => handleInputChange('content', e.target.value)}
                      placeholder="소중한 사람들에게 전하고 싶은 마음을 담아주세요..."
                      className="w-full border-2 border-gray-200 rounded-2xl p-4 focus:outline-none focus:border-rose-400 focus:ring-4 focus:ring-rose-100 transition-all resize-none"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      전달 날짜 (선택사항)
                    </label>
                    <input
                      type="date"
                      value={messageData.deliveryDate}
                      onChange={(e) => handleInputChange('deliveryDate', e.target.value)}
                      className="w-full border-2 border-gray-200 rounded-2xl p-4 focus:outline-none focus:border-rose-400 focus:ring-4 focus:ring-rose-100 transition-all"
                    />
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="private-message"
                      checked={messageData.isPrivate}
                      onChange={(e) => handleInputChange('isPrivate', e.target.checked)}
                      className="w-5 h-5 text-rose-600 rounded focus:ring-rose-500"
                    />
                    <label htmlFor="private-message" className="text-sm text-gray-700 flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      비공개 메시지
                    </label>
                  </div>
                </div>
                
                <button
                  onClick={handleSaveMessage}
                  disabled={!messageData.recipient || !messageData.title || !messageData.content}
                  className="w-full mt-8 bg-gradient-to-r from-rose-500 to-pink-500 text-white font-bold py-4 rounded-2xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                  <Send className="w-5 h-5" />
                  메시지 저장하기
                </button>
              </div>

              {/* Saved Messages */}
              <div className="bg-white rounded-3xl p-10 shadow-xl border border-gray-100">
                <h2 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-3">
                  <Heart className="w-8 h-8 text-rose-600" />
                  저장된 메시지
                </h2>
                
                <div className="space-y-6">
                  {savedMessages.map((message, index) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="p-6 rounded-2xl border-2 border-rose-100 bg-rose-50 hover:bg-rose-100 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-gray-900 mb-1">
                            {message.title}
                          </h3>
                          <p className="text-sm text-gray-600 mb-2">
                            {message.recipient}
                          </p>
                          <p className="text-xs text-gray-500">
                            작성일: {new Date(message.createdAt).toLocaleDateString('ko-KR')}
                          </p>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          message.status === 'draft'
                            ? 'bg-yellow-100 text-yellow-700'
                            : 'bg-green-100 text-green-700'
                        }`}>
                          {message.status === 'draft' ? '임시저장' : '예약됨'}
                        </div>
                      </div>
                      
                      <div className="flex gap-3">
                        <button className="text-sm text-rose-600 hover:text-rose-800 transition-colors font-medium">
                          편집하기
                        </button>
                        <button className="text-sm text-gray-600 hover:text-gray-800 transition-colors">
                          미리보기
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'memories' && (
            <motion.div
              key="memories"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-3xl p-12 shadow-xl border border-gray-100 text-center"
            >
              <div className="text-6xl mb-8">📸</div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">추억 정리</h2>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                소중한 추억들을 정리하고 가족들과 공유할 수 있는 기능을 준비 중입니다.
              </p>
              <button className="bg-gradient-to-r from-rose-500 to-pink-500 text-white font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                곧 출시 예정
              </button>
            </motion.div>
          )}

          {activeTab === 'documents' && (
            <motion.div
              key="documents"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-3xl p-12 shadow-xl border border-gray-100 text-center"
            >
              <div className="text-6xl mb-8">📋</div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">중요 문서 관리</h2>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                유언장, 재산 목록, 중요한 문서들을 안전하게 보관하고 관리할 수 있는 기능입니다.
              </p>
              <button className="bg-gradient-to-r from-rose-500 to-pink-500 text-white font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                곧 출시 예정
              </button>
            </motion.div>
          )}

          {activeTab === 'guidance' && (
            <motion.div
              key="guidance"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-8"
            >
              <div className="bg-white rounded-3xl p-10 shadow-xl border border-gray-100">
                <div className="text-4xl mb-6">💡</div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">웰다잉 가이드</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  아름다운 마무리를 위한 단계별 가이드와 체크리스트를 제공합니다.
                </p>
                <ul className="space-y-3 text-sm text-gray-600">
                  <li className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-rose-500" />
                    마지막 메시지 작성법
                  </li>
                  <li className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-rose-500" />
                    중요 문서 정리 방법
                  </li>
                  <li className="flex items-center gap-2">
                    <Star className="w-4 h-4 text-rose-500" />
                    가족과의 대화 가이드
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-3xl p-10 shadow-xl border border-gray-100">
                <div className="text-4xl mb-6">🤝</div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">전문가 상담</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  웰다잉 전문가와의 상담을 통해 개인에게 맞는 준비 과정을 안내받으세요.
                </p>
                <button className="w-full bg-gradient-to-r from-rose-500 to-pink-500 text-white font-semibold py-3 rounded-2xl hover:shadow-lg transition-all">
                  전문가 상담 신청
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}