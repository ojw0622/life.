import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useLocation,
} from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Star, Heart, Users, BookOpen, Clock, Sparkles, ArrowRight, Play, CheckCircle } from "lucide-react";

// Import pages
import {
  BrandingPage,
  CapsulePage,
  WellDyingPage,
  EducationPage,
  ExpertsPage,
} from "./pages";

function HeroSection() {
  return (
    <section className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 text-white py-32 px-6 overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-yellow-300 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-pink-300 rounded-full blur-2xl"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-left"
          >
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-6 py-3 mb-8">
              <Sparkles className="w-5 h-5" />
              <span className="text-sm font-medium">당신만의 특별한 이야기를 시작하세요</span>
            </div>
            
            <h1 className="text-6xl md:text-7xl font-bold mb-8 leading-tight">
              당신의 삶을
              <br />
              <span className="bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">
                기록하고 설계하세요
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl mb-12 leading-relaxed opacity-90 max-w-2xl">
              인터뷰, 타임캡슐, 웰다잉, 브랜딩, 교육, 전문가 매칭까지 — 
              당신만의 인생 스토리를 담은 혁신적인 플랫폼
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6">
              <Link to="/interview" className="group bg-white text-indigo-600 font-bold px-8 py-4 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 flex items-center justify-center gap-3">
                <Play className="w-6 h-6 group-hover:scale-110 transition-transform" />
                나의 이야기 시작하기
              </Link>
              <Link to="/branding" className="group bg-white/20 backdrop-blur-sm text-white font-semibold px-8 py-4 rounded-2xl border-2 border-white/30 hover:bg-white/30 transition-all duration-300 flex items-center justify-center gap-3">
                브랜딩 살펴보기
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>
          
          {/* Right Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10">
              {/* Main illustration container */}
              <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20">
                <div className="space-y-6">
                  {/* Story timeline illustration */}
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center">
                      <BookOpen className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="h-3 bg-white/30 rounded-full mb-2"></div>
                      <div className="h-2 bg-white/20 rounded-full w-3/4"></div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-pink-400 to-purple-500 rounded-2xl flex items-center justify-center">
                      <Heart className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="h-3 bg-white/30 rounded-full mb-2"></div>
                      <div className="h-2 bg-white/20 rounded-full w-2/3"></div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-teal-500 rounded-2xl flex items-center justify-center">
                      <Star className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="h-3 bg-white/30 rounded-full mb-2"></div>
                      <div className="h-2 bg-white/20 rounded-full w-4/5"></div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating elements */}
              <motion.div
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-6 -right-6 w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-2xl"
              >
                <Sparkles className="w-12 h-12 text-white" />
              </motion.div>
              
              <motion.div
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute -bottom-4 -left-4 w-20 h-20 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center shadow-2xl"
              >
                <Heart className="w-10 h-10 text-white" />
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full top-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center py-4">
          <Link
            to="/"
            className="flex items-center gap-3 text-2xl font-bold text-indigo-600 hover:text-indigo-800 transition-colors"
          >
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Heart className="w-7 h-7 text-white" />
            </div>
            LifeBranding
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLink to="/interview">인터뷰</NavLink>
            <NavLink to="/branding">브랜딩</NavLink>
            <NavLink to="/capsule">타임캡슐</NavLink>
            <NavLink to="/welldying">웰다잉</NavLink>
            <NavLink to="/education">교육</NavLink>
            <NavLink to="/experts">전문가</NavLink>
          </div>
          
          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-xl hover:bg-gray-100 transition-colors"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t border-gray-200 py-4 bg-white/95 backdrop-blur-md rounded-b-2xl"
            >
              <div className="flex flex-col space-y-4">
                <MobileNavLink to="/interview" onClick={() => setIsOpen(false)}>인터뷰</MobileNavLink>
                <MobileNavLink to="/branding" onClick={() => setIsOpen(false)}>브랜딩</MobileNavLink>
                <MobileNavLink to="/capsule" onClick={() => setIsOpen(false)}>타임캡슐</MobileNavLink>
                <MobileNavLink to="/welldying" onClick={() => setIsOpen(false)}>웰다잉</MobileNavLink>
                <MobileNavLink to="/education" onClick={() => setIsOpen(false)}>교육</MobileNavLink>
                <MobileNavLink to="/experts" onClick={() => setIsOpen(false)}>전문가</MobileNavLink>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}

function NavLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className="text-gray-700 hover:text-indigo-600 font-medium transition-colors relative group px-4 py-2 rounded-xl hover:bg-indigo-50"
    >
      {children}
    </Link>
  );
}

function MobileNavLink({ to, children, onClick }: { to: string; children: React.ReactNode; onClick: () => void }) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="text-gray-700 hover:text-indigo-600 font-medium transition-colors py-3 px-4 rounded-xl hover:bg-indigo-50"
    >
      {children}
    </Link>
  );
}

function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Heart className="w-7 h-7 text-white" />
              </div>
              <span className="text-2xl font-bold">LifeBranding</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md leading-relaxed">
              당신의 소중한 이야기를 기록하고 미래 세대에게 전달하는 특별한 플랫폼입니다. 
              인생의 모든 순간을 의미있게 만들어보세요.
            </p>
            <div className="flex space-x-4">
              <SocialIcon />
              <SocialIcon />
              <SocialIcon />
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-6 text-lg">서비스</h3>
            <ul className="space-y-3 text-gray-400">
              <li><Link to="/interview" className="hover:text-white transition-colors">인터뷰</Link></li>
              <li><Link to="/branding" className="hover:text-white transition-colors">브랜딩</Link></li>
              <li><Link to="/capsule" className="hover:text-white transition-colors">타임캡슐</Link></li>
              <li><Link to="/welldying" className="hover:text-white transition-colors">웰다잉</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-6 text-lg">지원</h3>
            <ul className="space-y-3 text-gray-400">
              <li><Link to="/education" className="hover:text-white transition-colors">교육</Link></li>
              <li><Link to="/experts" className="hover:text-white transition-colors">전문가</Link></li>
              <li><a href="#" className="hover:text-white transition-colors">고객지원</a></li>
              <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
          <p>© 2025 LifeBranding. Inspired by your story. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon() {
  return (
    <div className="w-12 h-12 bg-gray-800 rounded-xl flex items-center justify-center hover:bg-indigo-600 transition-colors cursor-pointer group">
      <Heart className="w-6 h-6 group-hover:scale-110 transition-transform" />
    </div>
  );
}

function HomePage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      <HeroSection />
      
      {/* Services Section */}
      <section className="py-32 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 rounded-full px-6 py-3 mb-8">
              <Sparkles className="w-5 h-5" />
              <span className="font-medium">우리의 서비스</span>
            </div>
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
              당신의 이야기를 위한 <br />
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                완벽한 도구들
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              인생의 모든 순간을 기록하고 공유할 수 있는 
              혁신적인 플랫폼을 경험해보세요.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard 
              title="인터뷰 자동화" 
              description="AI가 도와주는 스마트한 인생 인터뷰로 당신만의 이야기를 완성하세요"
              emoji="📝" 
              link="/interview"
              gradient="from-blue-500 to-cyan-500"
            />
            <ServiceCard 
              title="브랜딩 제작" 
              description="당신만의 개인 브랜드를 만들어 세상에 특별함을 보여주세요"
              emoji="📘" 
              link="/branding"
              gradient="from-purple-500 to-pink-500"
            />
            <ServiceCard 
              title="디지털 타임캡슐" 
              description="미래의 나에게 보내는 특별한 메시지와 추억을 담아보세요"
              emoji="📦" 
              link="/capsule"
              gradient="from-green-500 to-emerald-500"
            />
            <ServiceCard 
              title="웰다잉 콘텐츠" 
              description="아름다운 마무리를 위한 준비와 소중한 사람들에게 남길 메시지"
              emoji="🌸" 
              link="/welldying"
              gradient="from-rose-500 to-pink-500"
            />
            <ServiceCard 
              title="라이프 교육" 
              description="인생을 더 풍요롭게 만드는 다양한 교육과 성장 프로그램"
              emoji="🎓" 
              link="/education"
              gradient="from-orange-500 to-red-500"
            />
            <ServiceCard 
              title="전문가 매칭" 
              description="당신에게 맞는 전문가를 찾아 더 나은 삶을 설계해보세요"
              emoji="🤝" 
              link="/experts"
              gradient="from-indigo-500 to-purple-500"
            />
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-32 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 rounded-full px-6 py-3 mb-8">
                <Star className="w-5 h-5" />
                <span className="font-medium">왜 LifeBranding인가요?</span>
              </div>
              <h3 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8">
                당신의 이야기가 <br />
                <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  특별한 이유
                </span>
              </h3>
              <div className="space-y-8">
                <FeatureItem 
                  icon={<Users className="w-7 h-7" />}
                  title="개인 맞춤형 서비스"
                  description="당신만의 독특한 이야기에 맞춘 개인화된 경험을 제공합니다."
                />
                <FeatureItem 
                  icon={<Clock className="w-7 h-7" />}
                  title="시간을 초월한 기록"
                  description="현재의 순간을 영원히 보존하고 미래 세대와 공유할 수 있습니다."
                />
                <FeatureItem 
                  icon={<BookOpen className="w-7 h-7" />}
                  title="전문가 지원"
                  description="각 분야의 전문가들이 당신의 이야기를 더욱 풍성하게 만들어드립니다."
                />
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative z-10 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-3xl p-12 border border-indigo-100">
                <div className="text-center">
                  <div className="w-32 h-32 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl">
                    <Heart className="w-16 h-16 text-white" />
                  </div>
                  <h4 className="text-3xl font-bold text-gray-900 mb-6">당신의 이야기가 특별한 이유</h4>
                  <p className="text-gray-600 text-lg leading-relaxed">
                    모든 사람은 고유한 경험과 지혜를 가지고 있습니다. 
                    LifeBranding은 이러한 소중한 가치를 발견하고 보존하는 데 도움을 드립니다.
                  </p>
                  
                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-6 mt-12">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-indigo-600 mb-2">10K+</div>
                      <div className="text-sm text-gray-600">저장된 이야기</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-600 mb-2">500+</div>
                      <div className="text-sm text-gray-600">전문가</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-pink-600 mb-2">98%</div>
                      <div className="text-sm text-gray-600">만족도</div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating decorations */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute -top-6 -right-6 w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-20"
              ></motion.div>
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute -bottom-6 -left-6 w-32 h-32 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full opacity-20"
              ></motion.div>
            </motion.div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}

function ServiceCard({ title, description, emoji, link, gradient }: {
  title: string;
  description: string;
  emoji: string;
  link: string;
  gradient: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      whileHover={{ y: -8 }}
      className="group"
    >
      <Link
        to={link}
        className="block bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 h-full"
      >
        <div className={`w-20 h-20 bg-gradient-to-br ${gradient} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg`}>
          <span className="text-3xl">{emoji}</span>
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-indigo-600 transition-colors">
          {title}
        </h3>
        <p className="text-gray-600 leading-relaxed mb-6">
          {description}
        </p>
        <div className="flex items-center text-indigo-600 font-semibold group-hover:translate-x-2 transition-transform">
          자세히 보기 
          <ArrowRight className="w-5 h-5 ml-2" />
        </div>
      </Link>
    </motion.div>
  );
}

function FeatureItem({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start gap-6">
      <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center text-purple-600 flex-shrink-0 shadow-lg">
        {icon}
      </div>
      <div>
        <h4 className="text-xl font-semibold text-gray-900 mb-3">{title}</h4>
        <p className="text-gray-600 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

function LoadingSpinner() {
  return (
    <div className="flex justify-center items-center h-64">
      <div className="relative">
        <div className="animate-spin rounded-full h-20 w-20 border-t-4 border-b-4 border-indigo-500"></div>
        <div className="absolute inset-0 animate-ping rounded-full h-20 w-20 border border-indigo-300 opacity-20"></div>
      </div>
    </div>
  );
}

function InterviewPage() {
  const [answers, setAnswers] = useState(() => {
    const saved = localStorage.getItem("interviewAnswers");
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem("interviewAnswers", JSON.stringify(answers));
  }, [answers]);

  const questions = [
    {
      id: 0,
      question: "당신의 인생에서 가장 큰 전환점은 무엇이었나요?",
      placeholder: "인생을 바꾼 특별한 순간에 대해 자유롭게 작성해주세요...",
      icon: "🌟"
    },
    {
      id: 1,
      question: "삶을 바꿨던 선택 중 가장 어려웠던 결정은?",
      placeholder: "힘들었지만 중요했던 선택에 대해 이야기해주세요...",
      icon: "🤔"
    },
    {
      id: 2,
      question: "자신이 가장 자랑스러웠던 순간은 언제인가요?",
      placeholder: "뿌듯하고 자랑스러웠던 경험을 공유해주세요...",
      icon: "🏆"
    },
    {
      id: 3,
      question: "후대에게 꼭 남기고 싶은 당신의 메시지는?",
      placeholder: "미래 세대에게 전하고 싶은 지혜나 조언을 적어주세요...",
      icon: "💌"
    },
  ];

  const handleChange = (index: number, value: string) => {
    setAnswers((prev: any) => ({ ...prev, [index]: value }));
  };

  const completedAnswers = Object.keys(answers).filter(key => answers[key]?.trim()).length;
  const progress = (completedAnswers / questions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pt-32 pb-20">
      <motion.div
        className="max-w-5xl mx-auto px-6"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 rounded-full px-6 py-3 mb-8">
            <BookOpen className="w-5 h-5" />
            <span className="font-medium">인생 인터뷰</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">
            📋 당신의 <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">이야기</span>를 들려주세요
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            소중한 경험과 지혜를 기록하여 미래 세대에게 전달해보세요. 
            AI가 도와주는 스마트한 인터뷰 시스템입니다.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-3xl p-8 shadow-xl mb-12 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <span className="text-lg font-semibold text-gray-700">진행률</span>
            <span className="text-lg font-bold text-blue-600">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-4">
            <motion.div
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-4 rounded-full shadow-lg"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
          <div className="mt-4 text-sm text-gray-600">
            {completedAnswers}개 / {questions.length}개 질문 완료
          </div>
        </div>

        <div className="space-y-8">
          {questions.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-3xl p-10 shadow-xl border border-gray-100"
            >
              <div className="flex items-start gap-6 mb-8">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center text-white font-bold flex-shrink-0 shadow-lg">
                  <span className="text-2xl">{item.icon}</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    {item.question}
                  </h3>
                  <p className="text-gray-600">
                    자유롭게 작성해주세요. 길이에 제한은 없습니다.
                  </p>
                </div>
              </div>
              
              <textarea
                rows={6}
                className="w-full border-2 border-gray-200 rounded-2xl p-6 focus:outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-100 transition-all resize-none text-lg"
                value={answers[item.id] || ""}
                onChange={(e) => handleChange(item.id, e.target.value)}
                placeholder={item.placeholder}
              />
              
              {answers[item.id]?.trim() && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-6 flex items-center gap-3 text-green-600"
                >
                  <CheckCircle className="w-6 h-6" />
                  <span className="font-semibold">답변 완료</span>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {completedAnswers > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-16 text-center"
          >
            <div className="bg-white rounded-3xl p-12 shadow-xl border border-gray-100">
              <div className="text-6xl mb-6">🎉</div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">
                훌륭해요!
              </h3>
              <p className="text-xl text-gray-600 mb-8">
                {completedAnswers}개의 질문에 답변해주셨습니다. 
                {completedAnswers === questions.length 
                  ? " 모든 인터뷰가 완료되었습니다!" 
                  : ` ${questions.length - completedAnswers}개의 질문이 더 남았어요.`
                }
              </p>
              {completedAnswers === questions.length && (
                <button className="bg-gradient-to-r from-blue-500 to-purple-500 text-white font-bold px-10 py-4 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
                  인터뷰 결과 확인하기
                </button>
              )}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(timeout);
  }, [location.pathname]);

  return (
    <AnimatePresence mode="wait">
      {loading ? (
        <motion.div
          key="loading"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="min-h-screen flex items-center justify-center bg-gray-50"
        >
          <LoadingSpinner />
        </motion.div>
      ) : (
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
        >
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<HomePage />} />
            <Route path="/interview" element={<InterviewPage />} />
            <Route path="/branding" element={<BrandingPage />} />
            <Route path="/capsule" element={<CapsulePage />} />
            <Route path="/welldying" element={<WellDyingPage />} />
            <Route path="/education" element={<EducationPage />} />
            <Route path="/experts" element={<ExpertsPage />} />
          </Routes>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <AnimatedRoutes />
        <Footer />
      </div>
    </Router>
  );
}

export default App;